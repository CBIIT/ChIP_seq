These are the bed files for the domain calls based on the human IMR90 Hi-C data.

The files are in bed format, so each line represents one domain, with the information in each 
line being the chromosome, domain start, and domain end.

The domain calling is based on the 40kb normalized interaction matrices, so each domain start 
and end is a multiple of 40000.  

We have included the domain locations for each replicate individually, as well as the 
locations based on the combined interaction matrices.
